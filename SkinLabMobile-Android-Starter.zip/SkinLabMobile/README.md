# Skin Lab Mobile — versão inicial

Protótipo Android offline, sem permissões especiais. Inclui interface de inventário, seleção de AKR/M4/AWM, acabamentos e paletas, e uma prévia 3D estilizada giratória feita em Canvas.

## Como gerar o APK
1. Em um computador, instale o Android Studio (versão atual estável).
2. Extraia este ZIP e abra a pasta `SkinLabMobile` no Android Studio.
3. Aguarde o Gradle Sync. Se pedir para instalar Android SDK Platform 35, aceite.
4. Use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Clique em **locate** no aviso de conclusão. O APK de debug estará normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no Galaxy A14 4G
1. Transfira `app-debug.apk` para o celular.
2. Abra o arquivo pelo app Meus Arquivos.
3. Se o Android solicitar, permita instalação dessa fonte para o app usado e confirme.
4. Abra Skin Lab Mobile.

## Limitações
- A prévia é um modelo geométrico estilizado, não um modelo oficial nem fiel ao jogo.
- Não conecta ao Standoff 2 e não modifica o jogo.
- Para uma versão com modelos 3D detalhados, será necessário integrar modelos próprios/licenciados (por exemplo, glTF) e um renderizador 3D.
- Requer internet apenas para a primeira sincronização/build do Gradle no computador; o app final funciona offline.

## Requisitos técnicos
- Android Studio, Android SDK 35 e JDK 17 (normalmente incluído no Android Studio).
- `minSdk 23` (Android 6.0 ou superior).
